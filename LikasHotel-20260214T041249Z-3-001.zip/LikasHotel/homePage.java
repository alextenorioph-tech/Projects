import java.awt.*;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.plaf.FontUIResource;

public class homePage {

    
    static class Customer {
        String customerId;
        String name;
        String contact;
        String address;
        String dateTime;
        int pax;
        int nights;
        String roomType; // "Economy", "Premium-4", "Premium-2"
    }

    // storage for customers, indexed by generated numeric id
    private static final int MAX_CUSTOMERS = 100;
    private static final Customer[] customers = new Customer[MAX_CUSTOMERS];
    private static int nextCustomerSeq = 1; // numeric part for CID-A00001 etc.

    // total rooms by type (tweak as needed)
    private static final int TOTAL_ECONOMY_ROOMS   = 20;
    private static final int TOTAL_PREMIUM4_ROOMS  = 10;
    private static final int TOTAL_PREMIUM2_ROOMS  = 5;

    // fonts (production-grade readable)
    private static final Font MAIN_FONT = new Font("SansSerif", Font.PLAIN, 14);
    private static final Font TITLE_FONT = new Font("SansSerif", Font.BOLD, 16);

    // background panel
    static class BackgroundPanel extends JPanel {
        private final Image background;

        public BackgroundPanel(String pathOnClasspath) {
            java.net.URL imgURL = getClass().getResource(pathOnClasspath);
            if (imgURL == null) {
                throw new IllegalArgumentException("Background image not found: " + pathOnClasspath);
            }
            background = new ImageIcon(imgURL).getImage();
            setLayout(new GridBagLayout());
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
        }
    }

    // utility: set global font
    private static void setGlobalFont(FontUIResource fontResource) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof FontUIResource) {
                UIManager.put(key, fontResource);
            }
        }
    }

    // generate customer ID like CID-A00001
    private static String generateCustomerId() {
        return String.format("CID-A%05d", nextCustomerSeq);
    }

    // find customer by customerId
    private static Customer findCustomerById(String cid) {
        for (Customer c : customers) {
            if (c != null && c.customerId.equalsIgnoreCase(cid.trim())) {
                return c;
            }
        }
        return null;
    }

    // delete customer by customerId
    private static boolean deleteCustomerById(String cid) {
        for (int i = 0; i < customers.length; i++) {
            if (customers[i] != null && customers[i].customerId.equalsIgnoreCase(cid.trim())) {
                customers[i] = null;
                return true;
            }
        }
        return false;
    }

    // count booked rooms by roomType
    private static int countBooked(String roomType) {
        int count = 0;
        for (Customer c : customers) {
            if (c != null && roomType.equals(c.roomType)) {
                count++;
            }
        }
        return count;
    }

    // MENU BAR: logo (left) + search (right)
    public JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // logo on upper left
        java.net.URL logoURL = getClass().getResource("/images/logo.png");
        if (logoURL != null) {
            ImageIcon logoIcon = new ImageIcon(logoURL);
            Image scaled = logoIcon.getImage()
                    .getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaled));
            logoLabel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 10));
            menuBar.add(logoLabel);
        } else {
            System.err.println("Logo not found at /images/logo.png");
        }

        // stretchable glue to push search to the right
        menuBar.add(Box.createHorizontalGlue());

        JLabel searchLabel = new JLabel("Search CID: ");
        searchLabel.setFont(MAIN_FONT);
        menuBar.add(searchLabel);

        JTextField searchField = new JTextField(15);
        searchField.setFont(MAIN_FONT);
        menuBar.add(searchField);

        JButton searchButton = new JButton("Search");
        styleSquareButton(searchButton);
        menuBar.add(searchButton);

        Font smallFont = new Font("SansSerif", Font.PLAIN, 17);
        searchField.setFont(smallFont);

        int h = smallFont.getSize() + 10;
        Dimension fieldSize = searchField.getPreferredSize();
        Dimension smallSize = new Dimension(fieldSize.height, h);
        searchField.setPreferredSize(smallSize);
        searchField.setMaximumSize(smallSize);

        searchButton.addActionListener(e -> showCustomerSearchResult(searchField));
        searchField.addActionListener(e -> showCustomerSearchResult(searchField));

        return menuBar;
    }

    // show customer details dialog for given search field
    private void showCustomerSearchResult(JTextField searchField) {
        String cid = searchField.getText().trim();
        if (cid.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "Please enter a Customer ID (e.g., CID-A00001).",
                    "No ID",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Customer c = findCustomerById(cid);
        if (c == null) {
            JOptionPane.showMessageDialog(null,
                    "Customer ID not found.",
                    "Not Found",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog((Frame) null, "Customer Details - " + c.customerId, true);
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel infoPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;

        row = addInfoRow(infoPanel, gbc, row, "Customer ID:", c.customerId);
        row = addInfoRow(infoPanel, gbc, row, "Date & Time:", c.dateTime);
        row = addInfoRow(infoPanel, gbc, row, "Name:", c.name);
        row = addInfoRow(infoPanel, gbc, row, "Contact:", c.contact);
        row = addInfoRow(infoPanel, gbc, row, "Address:", c.address);
        row = addInfoRow(infoPanel, gbc, row, "No. of Pax:", String.valueOf(c.pax));
        row = addInfoRow(infoPanel, gbc, row, "Nights:", String.valueOf(c.nights));
        row = addInfoRow(infoPanel, gbc, row, "Room Type:", c.roomType);

        dialog.add(infoPanel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton cancelBookingBtn = new JButton("Cancel Booking");
        styleSquareButton(cancelBookingBtn);
        JButton closeBtn = new JButton("Close");
        styleSquareButton(closeBtn);

        btnPanel.add(cancelBookingBtn);
        btnPanel.add(closeBtn);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        cancelBookingBtn.addActionListener(ev -> {
            int confirm = JOptionPane.showConfirmDialog(dialog,
                    "Are you sure you want to cancel this booking?",
                    "Confirm Cancellation",
                    JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (deleteCustomerById(c.customerId)) {
                    JOptionPane.showMessageDialog(dialog,
                            "Booking cancelled.",
                            "Cancelled",
                            JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog,
                            "Failed to cancel booking (it may have been removed already).",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        closeBtn.addActionListener(ev -> dialog.dispose());

        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }

    // helper: add one row to infoPanel
    private int addInfoRow(JPanel panel, GridBagConstraints gbc, int row, String label, String value) {
        JLabel l = new JLabel(label);
        l.setFont(MAIN_FONT);
        JTextField f = new JTextField(value);
        f.setFont(MAIN_FONT);
        f.setEditable(false);

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(l, gbc);
        gbc.gridx = 1;
        panel.add(f, gbc);
        return row + 1;
    }

    // CONTENT PANE with background
    public Container createContentPane() {
        BackgroundPanel contentPane = new BackgroundPanel("/images/background.jpg");
        contentPane.setOpaque(false);
        contentPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;

        JButton addNew = new JButton("New Customer");
        styleSquareButton(addNew);
        contentPane.add(addNew, gbc);

        addNew.addActionListener(e -> {
            JFrame owner = (JFrame) SwingUtilities.getWindowAncestor(contentPane);
            showNewCustomerDialog(owner);
        });

        gbc.gridx = 1;
        JButton availableRooms = new JButton("Available Rooms");
        styleSquareButton(availableRooms);
        contentPane.add(availableRooms, gbc);

        availableRooms.addActionListener(e -> {
            JFrame owner = (JFrame) SwingUtilities.getWindowAncestor(contentPane);
            showAvailableRoomsDialog(owner);
        });

        gbc.gridx = 2;
        JButton printReceiptBtn = new JButton("Print Receipt");
        styleSquareButton(printReceiptBtn);
        contentPane.add(printReceiptBtn, gbc);

        printReceiptBtn.addActionListener(e -> {
            JFrame owner = (JFrame) SwingUtilities.getWindowAncestor(contentPane);
            showPrintReceiptDialog(owner);
        });

        return contentPane;
    }

    // style square-ish buttons
    private void styleSquareButton(JButton button) {
        button.setFont(MAIN_FONT);
        button.setFocusPainted(false);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setVerticalTextPosition(SwingConstants.BOTTOM);
        button.setPreferredSize(new Dimension(150, 120));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        button.setBackground(new Color(230, 233, 242));
        button.setOpaque(true);
    }

    // NEW CUSTOMER DIALOG
    private void showNewCustomerDialog(JFrame owner) {
        JDialog dialog = new JDialog(owner, "New Customer", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;

        String idStr = generateCustomerId();
        JLabel idLabel = new JLabel("Customer ID:");
        idLabel.setFont(MAIN_FONT);
        JTextField idField = new JTextField(idStr);
        idField.setFont(MAIN_FONT);
        idField.setEditable(false);

        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(idLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(idField, gbc);
        row++;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String now = LocalDateTime.now().format(dtf);
        JLabel dtLabel = new JLabel("Date & Time:");
        dtLabel.setFont(MAIN_FONT);
        JTextField dtField = new JTextField(now);
        dtField.setFont(MAIN_FONT);
        dtField.setEditable(false);

        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(dtLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(dtField, gbc);
        row++;

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(MAIN_FONT);
        JTextField nameField = new JTextField(20);
        nameField.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(nameField, gbc);
        row++;

        JLabel contactLabel = new JLabel("Contact Number:");
        contactLabel.setFont(MAIN_FONT);
        JTextField contactField = new JTextField(20);
        contactField.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(contactLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(contactField, gbc);
        row++;

        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setFont(MAIN_FONT);
        JTextField addressField = new JTextField(20);
        addressField.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(addressLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(addressField, gbc);
        row++;

        JLabel paxLabel = new JLabel("No. of Pax:");
        paxLabel.setFont(MAIN_FONT);
        JSpinner paxSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
        paxSpinner.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(paxLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(paxSpinner, gbc);
        row++;

        JLabel nightsLabel = new JLabel("Nights of stay:");
        nightsLabel.setFont(MAIN_FONT);
        JSpinner nightsSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 365, 1));
        nightsSpinner.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(nightsLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(nightsSpinner, gbc);
        row++;

        JLabel roomTypeLabel = new JLabel("Room type:");
        roomTypeLabel.setFont(MAIN_FONT);
        String[] roomOptions = {
                "Economy (up to 6 pax, ₱699/night/pax)",
                "Premium (up to 4 pax, ₱899/night/pax)",
                "Premium (2 pax, ₱1099/night/pax)"
        };
        JComboBox<String> roomTypeCombo = new JComboBox<>(roomOptions);
        roomTypeCombo.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(roomTypeLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(roomTypeCombo, gbc);
        row++;

        dialog.add(formPanel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveBtn = new JButton("Save");
        styleSquareButton(saveBtn);
        JButton closeBtn = new JButton("Close");
        styleSquareButton(closeBtn);
        btnPanel.add(saveBtn);
        btnPanel.add(closeBtn);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        saveBtn.addActionListener(ev -> {
            int index = nextCustomerSeq - 1;
            if (index < 0 || index >= MAX_CUSTOMERS) {
                JOptionPane.showMessageDialog(dialog,
                        "Customer storage is full.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            Customer c = new Customer();
            c.customerId = idField.getText().trim();
            c.dateTime = dtField.getText().trim();
            c.name = nameField.getText().trim();
            c.contact = contactField.getText().trim();
            c.address = addressField.getText().trim();
            c.pax = (Integer) paxSpinner.getValue();
            c.nights = (Integer) nightsSpinner.getValue();

            String selection = (String) roomTypeCombo.getSelectedItem();
            if (selection.startsWith("Economy")) {
                c.roomType = "Economy";
            } else if (selection.startsWith("Premium (up to 4")) {
                c.roomType = "Premium-4";
            } else {
                c.roomType = "Premium-2";
            }

            customers[index] = c;
            nextCustomerSeq++;

            JOptionPane.showMessageDialog(dialog,
                    "Customer saved with ID " + c.customerId,
                    "Saved",
                    JOptionPane.INFORMATION_MESSAGE);
            dialog.dispose();
        });

        closeBtn.addActionListener(ev -> dialog.dispose());

        dialog.pack();
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }

    // AVAILABLE ROOMS DIALOG with availability + floor info
    private void showAvailableRoomsDialog(JFrame owner) {
        JDialog dialog = new JDialog(owner, "Available Rooms", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setResizable(false);

        JPanel roomsPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        roomsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        Dimension imageSize = new Dimension(200, 150);

        int bookedEconomy  = countBooked("Economy");
        int bookedPrem4    = countBooked("Premium-4");
        int bookedPrem2    = countBooked("Premium-2");

        int availEconomy   = Math.max(0, TOTAL_ECONOMY_ROOMS  - bookedEconomy);
        int availPrem4     = Math.max(0, TOTAL_PREMIUM4_ROOMS - bookedPrem4);
        int availPrem2     = Math.max(0, TOTAL_PREMIUM2_ROOMS - bookedPrem2);

        // ECONOMY (1st floor)
        JPanel economyPanel = new JPanel(new BorderLayout(5, 5));
        economyPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        JLabel economyImageLabel = new JLabel(resizeIcon("/images/economyRoom.jpg", imageSize),
                SwingConstants.CENTER);
        economyImageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel economyTextLabel = new JLabel(
                "<html><center>" +
                "Economy Room<br/>" +
                "Up to 6 pax (toddlers 3 and below excluded)<br/>" +
                "₱699 per night per pax<br/><br/>" +
                "<b>Floor:</b> 1st Floor<br/>" +
                "<b>Available rooms:</b> " + availEconomy + " / " + TOTAL_ECONOMY_ROOMS +
                "</center></html>",
                SwingConstants.CENTER
        );
        economyTextLabel.setFont(MAIN_FONT);

        economyPanel.add(economyImageLabel, BorderLayout.CENTER);
        economyPanel.add(economyTextLabel, BorderLayout.SOUTH);

        // PREMIUM 4-PAX (1st floor)
        JPanel premium4Panel = new JPanel(new BorderLayout(5, 5));
        premium4Panel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        JLabel premium4ImageLabel = new JLabel(resizeIcon("/images/premiumRoom.jpg", imageSize),
                SwingConstants.CENTER);
        premium4ImageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel premium4TextLabel = new JLabel(
                "<html><center>" +
                "Premium Room<br/>" +
                "Up to 4 pax<br/>" +
                "₱899 per night per pax<br/><br/>" +
                "<b>Floor:</b> 1st Floor<br/>" +
                "<b>Available rooms:</b> " + availPrem4 + " / " + TOTAL_PREMIUM4_ROOMS +
                "</center></html>",
                SwingConstants.CENTER
        );
        premium4TextLabel.setFont(MAIN_FONT);

        premium4Panel.add(premium4ImageLabel, BorderLayout.CENTER);
        premium4Panel.add(premium4TextLabel, BorderLayout.SOUTH);

        // PREMIUM 2-PAX (2nd floor)
        JPanel premium2Panel = new JPanel(new BorderLayout(5, 5));
        premium2Panel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        JLabel premium2ImageLabel = new JLabel(resizeIcon("/images/premiumRoom.jpg", imageSize),
                SwingConstants.CENTER);
        premium2ImageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel premium2TextLabel = new JLabel(
                "<html><center>" +
                "Premium Room for 2 pax<br/>" +
                "₱1099 per night per pax<br/><br/>" +
                "<b>Floor:</b> 2nd Floor<br/>" +
                "<b>Available rooms:</b> " + availPrem2 + " / " + TOTAL_PREMIUM2_ROOMS +
                "</center></html>",
                SwingConstants.CENTER
        );
        premium2TextLabel.setFont(MAIN_FONT);

        premium2Panel.add(premium2ImageLabel, BorderLayout.CENTER);
        premium2Panel.add(premium2TextLabel, BorderLayout.SOUTH);

        roomsPanel.add(economyPanel);
        roomsPanel.add(premium4Panel);
        roomsPanel.add(premium2Panel);

        dialog.add(roomsPanel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton closeBtn = new JButton("Close");
        styleSquareButton(closeBtn);
        btnPanel.add(closeBtn);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        closeBtn.addActionListener(e -> dialog.dispose());

        dialog.pack();
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }

    // resize icon to uniform size
    private Icon resizeIcon(String path, Dimension size) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL == null) {
            return new ImageIcon(new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB));
        }
        ImageIcon original = new ImageIcon(imgURL);
        Image scaled = original.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }

    // PRINT RECEIPT DIALOG
    private void showPrintReceiptDialog(JFrame owner) {
        String cid = JOptionPane.showInputDialog(owner,
                "Enter Customer ID to print receipt (e.g., CID-A00001):",
                "Print Receipt",
                JOptionPane.QUESTION_MESSAGE);
        if (cid == null || cid.trim().isEmpty()) {
            return;
        }
        Customer c = findCustomerById(cid);
        if (c == null) {
            JOptionPane.showMessageDialog(owner,
                    "Customer ID not found.",
                    "Not Found",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int pax = c.pax;
        int nights = c.nights;
        int ratePerPaxPerNight;
        String roomDesc;

        switch (c.roomType) {
            case "Economy":
                ratePerPaxPerNight = 699;
                roomDesc = "Economy (up to 6 pax)";
                break;
            case "Premium-4":
                ratePerPaxPerNight = 899;
                roomDesc = "Premium (up to 4 pax)";
                break;
            case "Premium-2":
            default:
                ratePerPaxPerNight = 1099;
                roomDesc = "Premium Room for 2 pax";
                break;
        }

        double total = pax * nights * ratePerPaxPerNight;
        DecimalFormat df = new DecimalFormat("0.00");
        String stringTotal = df.format(total);

        StringBuilder sb = new StringBuilder();
        sb.append("Likas Hotel Booking Receipt\n");
        sb.append("====================================\n");
        sb.append("Customer ID: ").append(c.customerId).append("\n");
        sb.append("Name       : ").append(c.name).append("\n");
        sb.append("Contact    : ").append(c.contact).append("\n");
        sb.append("Address    : ").append(c.address).append("\n");
        sb.append("Date/Time  : ").append(c.dateTime).append("\n");
        sb.append("------------------------------------\n");
        sb.append("Room Type  : ").append(roomDesc).append("\n");
        sb.append("Pax        : ").append(pax).append("\n");
        sb.append("Nights     : ").append(nights).append("\n");
        sb.append("Rate       : ₱").append(ratePerPaxPerNight).append(" / night / pax\n");
        sb.append("------------------------------------\n");
        sb.append("Total      : ₱").append(stringTotal).append("\n");
        sb.append("====================================\n");

        JDialog dialog = new JDialog(owner, "Receipt - " + c.customerId, true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setResizable(false);
        JTextArea receiptArea = new JTextArea(sb.toString(), 15, 40);
        receiptArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        receiptArea.setEditable(false);
        dialog.add(new JScrollPane(receiptArea), BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton printBtn = new JButton("Print");
        styleSquareButton(printBtn);
        JButton closeBtn = new JButton("Close");
        styleSquareButton(closeBtn);
        btnPanel.add(printBtn);
        btnPanel.add(closeBtn);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        printBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(dialog,
                    "Sending receipt to printer...",
                    "Print",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        closeBtn.addActionListener(e -> dialog.dispose());

        dialog.pack();
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }

    private static void createAndShowGUI() {
        setGlobalFont(new FontUIResource(MAIN_FONT));

        JFrame frame = new JFrame("Likas Hotel Booking System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        homePage demo = new homePage();
        frame.setJMenuBar(demo.createMenuBar());
        frame.setContentPane(demo.createContentPane());

        frame.setSize(800, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginWindow login = new LoginWindow(null);
            login.setVisible(true);

            if (login.isSucceeded()) {
                createAndShowGUI();
            } else {
                System.exit(0);
            }
        });
    }
}
