import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class LoginWindow extends JDialog {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private boolean succeeded = false;

    public LoginWindow(Frame parent) {
        super(parent, "Login", true);
        initUI(parent);
    }

    private void initUI(Frame parent) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;

        // Username
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Username:"), gbc);

        usernameField = new JTextField(15);
        gbc.gridx = 1;
        panel.add(usernameField, gbc);
        row++;

        // Password
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Password:"), gbc);

        passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(passwordField, gbc);
        row++;

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton loginButton = new JButton("Login");
        JButton cancelButton = new JButton("Cancel");

        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);

        loginButton.addActionListener(this::onLogin);
        cancelButton.addActionListener(e -> {
            succeeded = false;
            dispose();
        });

        getContentPane().setLayout(new BorderLayout(10, 10));
        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(parent);
    }

    private void onLogin(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if ("admin".equals(username) && "secret".equals(password)) {
            JOptionPane.showMessageDialog(this,
                    "Login successful.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            succeeded = true;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Invalid username or password.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            // clear password only
            passwordField.setText("");
            succeeded = false;
        }
    }

    public boolean isSucceeded() {
        return succeeded;
    }
}
