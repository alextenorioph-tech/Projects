# FreshCart — Detailed Documentation

# Contributors

The FreshCart project was developed and maintained by:

- Ben Israel Seatriz — Developer — @seatrizbir@students.nu-fairview.edu.ph
- Alexander Tenorio — Developer — @insert your email
- Raphael Sadia — Developer — @insert your email
- Joshua Maido — Documentation — @insert your email
- Mark Rhovie Wagwag — Documentation — @insert your email

Summary
- FreshCart is a small Streamlit-based grocery storefront demo that implements product browsing, a cart, checkout/payment simulation, recent items history, and a delivery status panel.
- The code follows Python best-practices and PEP guidance (PEP 8, 257, 484). Public APIs are documented below.
- This README documents project layout, configuration, how the app runs, and every public function, data structure, and top-level variable visible in the repository.
- The code uses dictionaries and lists

Table of contents
- Project layout
- Installation & environment
- Running the app (Windows)
- Project configuration
- Files and modules (exhaustive API & behavior)
  - app/main.py
  - app/frontend.py
  - app/home.py
  - app/cart.py
  - app/payment.py
  - app/data_structures.py
- Important variables and session state
- How the app works (request/flow lifecycle)
- Testing
- Style and PEP compliance notes
- Security & production notes
- Contribution and license

Project layout
- .streamlit/config.toml — Streamlit theme/config (project root)
- README.md — this file
- app/
  - frontend.py — Streamlit UI and entrypoint
  - home.py — Product model, product loader, helpers like format_currency and delivery estimate
  - cart.py — cart manipulation helpers and helpers to build displayable cart lines
  - payment.py — payment flow helpers and payment-summary builder
  - data_structures.py — small in-project data structures (Stack, etc.)
  - main.py — minimal launcher that calls app.frontend.run_app()
- images/ — product images used by the UI

Installation & environment
- Python: 3.9+ recommended (3.10/3.11 OK).
- Virtual environment and Install runtime dependencies: (use CMD):
  - python -m venv .venv
  - .\.venv\Scripts\activate.bat
  - python -m pip install --upgrade pip
  - pip install -r requirements.txt
- Optional dev/test:
  - pip install pytest black isort flake8 mypy

Running the app (Windows)
- From project root (FreshCart):
- Use main.py as launcher:
  - streamlit run app/main.py

Project configuration
- .streamlit/config.toml (project root) is loaded automatically by Streamlit. Example used by this project:
  - base = "light"
  - primaryColor = "#2f6f44"
  - backgroundColor = "#F6F7F8" (Subtle Off-White inspired by Notion UI)
  - secondaryBackgroundColor = "#F7F7F7" 
  - textColor = "#0f1720"
  - font = "sans serif"
- No additional code is required to read config.toml — Streamlit auto-loads it on start.

Files and modules — API and behavior
- Note: signatures and behavior below reflect the public surface used by the app. Implementation details are intentionally omitted where not required. All public functions include a brief docstring-style description, parameters, return, and side effects.

1) app/main.py
- Purpose: application launcher. Minimal wrapper that calls run_app() from frontend.
- Public behavior:
  - If present, main.py typically contains:
    - if __name__ == "__main__": run_app()
  - No complex logic; module exists so Streamlit can run `streamlit run main.py` or `streamlit run app/frontend.py`.

2) app/frontend.py
- Purpose: Streamlit UI. Central entrypoint `run_app()` and render helpers for pages: home, cart, payment, product dialog and delivery status.
- Public functions:
  - run_app() -> None
    - Entrypoint used by Streamlit. Responsible for set_page_config, ensuring session state defaults, syncing query params, and rendering the top header and the active page.
    - Side effects: Updates/reads st.session_state extensively; calls st.set_page_config and various st.* UI calls.
  - _ensure_state() -> None
    - Ensures default keys exist on st.session_state (page, cart, selected_product_id, detail_quantity, show_delivery, payment_method, payment_confirmation, last_checkout_items, recent_product_stack, fulfillment_queue).
    - Side effects: sets missing keys with sensible defaults.
  - _sync_query_params() -> None
    - Reads st.query_params and sets st.session_state.page when `page` param is present (values: "home", "cart", "payment").
  - _set_page(page: str) -> None
    - Helper to change page state and update query params. Resets selected product detail on page change.
  - _render_header() -> None
    - Renders top header with logo (clickable), Delivery toggle button and Cart button with item count.
    - When st.session_state.show_delivery is truthy, calls _render_delivery_status().
  - _render_delivery_status() -> None
    - Displays delivery panel: delivery estimate, status/progress, route origin/destination, estimated arrival, same-day availability notice, and last checkout items.
    - Reads get_delivery_estimate() (from home.py) and uses cart lines via cart.build_cart_lines.
    - Important behavior: If st.session_state.payment_confirmation is falsy, the UI shows a warning "No items ready for delivery status yet." Otherwise displays progress, info and items.
  - _render_home_page() -> None
    - Renders homepage: site title/caption and product grid (calls _render_product_grid) and recently viewed stack (calls _render_recently_viewed_stack). If a product is selected, opens the product dialog (Streamlit dialog).
  - _render_product_grid() -> None
    - Renders products in rows of three using st.columns and _render_product_card for each product.
  - _render_product_card(product: Product) -> None
    - Renders image, category, name, price and buttons: "View" -> opens product dialog and triggers rerun; "Add to cart" if present in UI.
    - Uses server-side processed images (shadow) when available.
  - _open_product(product_id: str) -> None
    - Pushes `product_id` to recently viewed stack, sets st.session_state.selected_product_id and detail_quantity (to default 1).
  - _push_recent_product(product_id: str) -> None
    - Maintains LIFO recent_product_stack using Stack from data_structures.py; keeps up to last 5 items.
  - _render_recently_viewed_stack() -> None
    - Renders the "Recently viewed" section from the recent_product_stack.
  - _render_product_dialog(product: Product) -> None
    - Streamlit dialog (decorated with @st.dialog) showing product details, quantity controls and "Add to cart" behaviour which updates st.session_state.cart and shows a toast.
  - _render_cart_page() -> None
    - Renders cart page header, each cart line (calls _render_cart_line), totals and Checkout button.
    - If cart empty, shows a message and a "Browse products" button returning to home.
  - _render_cart_line(product: Product, quantity: int) -> None
    - Displays a cart line with image, description, quantity controls (-/+), subtotal, and a Remove button.
    - Buttons mutate st.session_state.cart via cart helpers and rerun.
  - _render_payment_page() -> None
    - Renders payment view: order summary, totals, payment method selection, Pay action.
    - On successful payment (confirm_payment), sets st.session_state.payment_confirmation and last_checkout_items, emplaces fulfillment queue, and empties st.session_state.cart.
  - _render_confirmation() -> None
    - Shows payment confirmation message (success/info).
- Top-level variables:
  - PRODUCTS: populated once as get_products() at module import. Contains mapping of product_id->Product from home.py.
- Notes about UI:
  - This frontend intentionally avoids unsafe HTML/CSS injection; it relies on Streamlit widgets.
  - All interactive actions set `st.session_state` keys and call st.rerun() where needed to force fresh rendering.

3) app/home.py
- Purpose: product model, product loader, helper utilities like format_currency and get_delivery_estimate.
- Public items (used by frontend):
  - Product (class / dataclass)
    - Typical fields (based on usage): id: str, name: str, price: float, description: str, category: str, image: Path or str, unit: str, stock: int
    - Behavior: lightweight model used by UI rendering and cart/payment logic.
  - get_products() -> dict[str, Product]
    - Returns PRODUCTS mapping used by frontend. Typically reads static data in code or from a data file and resolves image paths (images/…).
  - format_currency(amount: float) -> str
    - Returns a user-facing formatted currency string, e.g. "$1.25".
  - get_delivery_estimate() -> DeliveryEstimate
    - Returns a simple object with the delivery status fields referenced by frontend:
      - status: str
      - message: str
      - display_time: str
      - origin: str
      - destination: str
      - same_day: bool
    - Behavior: used for status display. Implementation may be deterministic/mock or integrate with a routing service; frontend expects the fields above.

4) app/cart.py
- Purpose: manipulate cart contents in st.session_state and convert raw cart mapping into displayable lines.
- Public functions (referenced by frontend):
  - add_to_cart(cart: dict[str,int], product_id: str, qty: int = 1) -> None
    - Increments quantity for product_id in the provided cart mapping by qty (default 1). Should cap at product stock if enforced elsewhere.
    - Side effect: mutates the `cart` dict in place.
  - decrease_quantity(cart: dict[str,int], product_id: str, qty: int = 1) -> None
    - Decreases quantity by qty; if quantity reaches zero or becomes non-positive, removes the key from cart.
  - remove_from_cart(cart: dict[str,int], product_id: str) -> None
    - Removes product from cart regardless of current quantity.
  - count_items(cart: dict[str,int]) -> int
    - Returns total number of items in the cart (sum of quantities).
  - build_cart_lines(cart: dict[str,int], products: dict[str, Product]) -> list[CartLine]
    - Converts the raw dict into a list of CartLine objects used by the frontend. CartLine commonly has:
      - product: Product
      - quantity: int
      - subtotal: float
  - cart_total(lines: Iterable[CartLine]) -> float
    - Sums line subtotals and returns total float.
- Behavior and side effects:
  - All functions are pure mutation helpers except build_cart_lines and cart_total which are read-only.

5) app/payment.py
- Purpose: payment simulation and fulfillment queue helpers.
- Public variables and functions:
  - PAYMENT_METHODS: list[str]
    - Example values: ["Credit card", "Cash on delivery", "Mobile pay"] — used by frontend to render selectable buttons.
  - create_payment_summary(lines: Iterable[CartLine]) -> PaymentSummary
    - Returns structured payment summary with fields:
      - lines: list[CartLine] (order lines)
      - subtotal: float
      - delivery_fee: float
      - total: float
    - Delivery fee computation is encapsulated here.
  - confirm_payment(payment_method: str, amount: float) -> PaymentConfirmation
    - Simulates a payment. Behavior:
      - If payment_method is None or unsupported, raises ValueError.
      - Otherwise returns a PaymentConfirmation containing:
        - order_id: str
        - payment_method: str
        - message: str
      - The frontend stores this object in st.session_state.payment_confirmation.
  - create_fulfillment_queue(lines: Iterable[CartLine]) -> Stack or Queue
    - Returns a data-structure (Stack/Queue) of items to be fulfilled. Frontend stores it in st.session_state.fulfillment_queue (likely as list).
- Notes:
  - This module intentionally simulates payment. For production, replace confirm_payment with integration to a real payments provider and secure handling of keys.

6) app/data_structures.py
- Purpose: small, simple in-project data structures referenced by frontend.
- Items:
  - Stack[T]
    - Typical methods:
      - push(item: T) -> None
      - pop() -> T
      - peek() -> T | None
      - to_list() -> list[T]
    - Behavior: LIFO structure used to track recently viewed product ids.
- Implementation details: minimal; used to keep `recent_product_stack` deterministic and easy to read/write to st.session_state (converted to plain lists for serialization).

Important variables and session state
- st.session_state keys (created by _ensure_state in frontend.py):
  - page: str — one of "home" (default), "cart", "payment"
  - cart: dict[str,int] — mapping product_id -> quantity
  - selected_product_id: str | None — product id that is currently open in product dialog
  - detail_quantity: int — quantity shown/managed in product detail dialog
  - show_delivery: bool — whether delivery panel is open in header
  - payment_method: str | None — selected payment method on payment page
  - payment_confirmation: PaymentConfirmation | None — truthy when payment completed
  - last_checkout_items: list[str] — last set of items purchased (used by delivery status)
  - recent_product_stack: list[str] — serialized stack of recently viewed product ids (LIFO)
  - fulfillment_queue: list[...] — serialized queue/stack of items to fulfill after successful payment
- Top-level module variable:
  - PRODUCTS: dict[str, Product] — loaded at import via get_products()

How the app works (high-level flow)
1. Start
   - streamlit runs app/frontend.py (or main.py) and calls run_app().
   - st.set_page_config configures page and Streamlit reads .streamlit/config.toml for theme on startup.
2. Initialization
   - run_app calls _ensure_state which ensures session defaults.
   - PRODUCTS is already loaded at module import.
3. Header & navigation
   - _render_header draws logo, Delivery toggle and Cart button. Clicks update st.session_state and call st.rerun() to re-render.
4. Pages
   - run_app reads st.session_state.page and calls the corresponding page renderer:
     - home: _render_home_page -> product grid + recently viewed
     - cart: _render_cart_page -> cart lines + checkout
     - payment: _render_payment_page -> summary + payment actions
5. Product browsing
   - _render_product_card displays product image, data and opens a detail dialog. Opening a product pushes to recent stack(data_structures.py).
6. Cart & checkout
   - add_to_cart, decrease_quantity and remove_from_cart mutate the cart mapping stored in st.session_state. build_cart_lines and cart_total produce the UI lines and totals.
7. Payment
   - On Pay, frontend calls confirm_payment; on success it stores payment_confirmation, last_checkout_items and fulfillment_queue and empties cart.
8. Delivery status
   - Delivery panel reads get_delivery_estimate and last checkout items. It only shows full progress information if payment_confirmation is present; otherwise displays a helpful warning that no item is ready for delivery.

Testing
- Use pytest for unit tests.
- Test targets:
  - cart functions: add_to_cart, decrease_quantity, remove_from_cart, count_items, build_cart_lines
  - payment functions: create_payment_summary, confirm_payment (error and success cases)
  - data_structures: Stack push/pop/peek/to_list invariants
  - home: format_currency and product loading (images referenced exist)
- Isolate Streamlit-dependent code in unit tests. Test logic functions directly without rendering UI. Use monkeypatch or fixtures to emulate environment.

Style and PEP compliance notes
- PEP 8: follow 79/88 char limit, consistent naming, imports grouped standard->third party->local.
- PEP 257: all public functions and classes should have docstrings describing purpose, args, returns and side effects.
- PEP 484: use type hints on public functions and dataclasses where feasible to make intent clear.
- Recommended tools:
  - black (formatting)
  - isort (imports)
  - flake8 (linting)
  - mypy (static typing checks)

Security & production notes
- Avoid unsafe HTML/CSS injection (unsafe_allow_html=True) in production. This project intentionally renders UI using Streamlit widgets.
- Do not store secrets in code or repo. Use environment variables or a secret manager for API keys.
- For production payment flows, replace confirm_payment with secure integration to PCI-compliant provider or tokenized gateway.
- Validate any user input and sanitize data that might appear in logs or external services.

Contribution & license
- Fork -> feature branch -> PR. Include tests and keep changes small.
- Add a LICENSE file (MIT or other) in the project root.

Appendix — quick reference / function signature examples
- get_products() -> dict[str, Product]
- format_currency(amount: float) -> str
- get_delivery_estimate() -> DeliveryEstimate (status,str message,str display_time,str origin,str destination,bool same_day)
- add_to_cart(cart: dict[str,int], product_id: str, qty: int = 1) -> None
- decrease_quantity(cart: dict[str,int], product_id: str, qty: int = 1) -> None
- remove_from_cart(cart: dict[str,int], product_id: str) -> None
- build_cart_lines(cart: dict[str,int], products: dict[str, Product]) -> list[CartLine]
- cart_total(lines: Iterable[CartLine]) -> float
- create_payment_summary(lines: Iterable[CartLine]) -> PaymentSummary
- confirm_payment(method: str, amount: float) -> PaymentConfirmation
- Stack[T].push(item: T) -> None; .pop() -> T; .peek() -> T | None; .to_list() -> list[T]


