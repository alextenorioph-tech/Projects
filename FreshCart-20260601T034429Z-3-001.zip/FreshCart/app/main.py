from __future__ import annotations

from frontend import run_app


def main() -> None:
    """Keep startup intentionally small: import app modules and run the frontend."""

    run_app()


if __name__ == "__main__":
    main()
