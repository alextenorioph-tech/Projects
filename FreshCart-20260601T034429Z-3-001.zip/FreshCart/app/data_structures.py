from __future__ import annotations

from collections import deque
from collections.abc import Iterable, Iterator
from typing import Generic, TypeVar


T = TypeVar("T")


class Stack(Generic[T]):
    """LIFO collection used when the newest item should be handled first."""

    def __init__(self, items: Iterable[T] | None = None) -> None:
        self._items = list(items or [])

    def push(self, item: T) -> None:
        self._items.append(item)

    def pop(self) -> T:
        return self._items.pop()

    def peek(self) -> T | None:
        return self._items[-1] if self._items else None

    def to_list(self) -> list[T]:
        return list(self._items)

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)


class Queue(Generic[T]):
    """FIFO collection used when the oldest item should be handled first."""

    def __init__(self, items: Iterable[T] | None = None) -> None:
        self._items = deque(items or [])

    def enqueue(self, item: T) -> None:
        self._items.append(item)

    def dequeue(self) -> T:
        return self._items.popleft()

    def peek(self) -> T | None:
        return self._items[0] if self._items else None

    def to_list(self) -> list[T]:
        return list(self._items)

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)
