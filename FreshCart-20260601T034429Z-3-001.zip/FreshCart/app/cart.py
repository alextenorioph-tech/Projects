from __future__ import annotations

from dataclasses import dataclass

from home import Product


@dataclass(frozen=True)
class CartLine:
    """A cart row combines stable product data with the customer's quantity."""

    product: Product
    quantity: int

    @property
    def subtotal(self) -> float:
        return self.product.price * self.quantity


def add_to_cart(cart: dict[str, int], product_id: str, quantity: int = 1) -> dict[str, int]:
    """Add quantity while keeping cart values positive and predictable."""

    if quantity < 1:
        return cart
    cart[product_id] = cart.get(product_id, 0) + quantity
    return cart


def decrease_quantity(cart: dict[str, int], product_id: str) -> dict[str, int]:
    """Decrease a line quantity, removing the item when it reaches zero."""

    if product_id not in cart:
        return cart
    cart[product_id] -= 1
    if cart[product_id] <= 0:
        cart.pop(product_id, None)
    return cart


def remove_from_cart(cart: dict[str, int], product_id: str) -> dict[str, int]:
    cart.pop(product_id, None)
    return cart


def build_cart_lines(cart: dict[str, int], products: dict[str, Product]) -> list[CartLine]:
    """Ignore unavailable product ids so stale session data cannot break checkout."""

    return [
        CartLine(product=products[product_id], quantity=quantity)
        for product_id, quantity in cart.items()
        if product_id in products and quantity > 0
    ]


def count_items(cart: dict[str, int]) -> int:
    return sum(cart.values())


def cart_total(lines: list[CartLine]) -> float:
    return sum(line.subtotal for line in lines)
