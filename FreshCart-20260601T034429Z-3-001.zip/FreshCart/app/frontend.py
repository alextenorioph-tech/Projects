from __future__ import annotations

from pathlib import Path

import streamlit as st

from cart import (
    add_to_cart,
    build_cart_lines,
    cart_total,
    count_items,
    decrease_quantity,
    remove_from_cart,
)
from data_structures import Stack
from home import Product, format_currency, get_delivery_estimate, get_logo_path, get_products
from payment import PAYMENT_METHODS, confirm_payment, create_fulfillment_queue, create_payment_summary


PRODUCTS = get_products()


def run_app() -> None:
    """Streamlit entry point used by main.py."""

    st.set_page_config(
        page_title="FreshCart Grocery",
        page_icon=str(get_logo_path()),
        layout="wide",
        initial_sidebar_state="collapsed",
    )
    _ensure_state()
    _sync_query_params()
    _render_header()

    page = st.session_state.page
    if page == "cart":
        _render_cart_page()
    elif page == "payment":
        _render_payment_page()
    else:
        _render_home_page()


def _ensure_state() -> None:
    defaults = {
        "page": "home",
        "cart": {},
        "selected_product_id": None,
        "detail_quantity": 1,
        "show_delivery": False,
        "payment_method": None,
        "payment_confirmation": None,
        "last_checkout_items": [],
        "recent_product_stack": [],
        "fulfillment_queue": [],
    }
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


def _sync_query_params() -> None:
    """Keep direct page links working without using query params for product pop-ups."""

    params = st.query_params
    page = params.get("page")

    if page in {"home", "cart", "payment"}:
        st.session_state.page = page


def _set_page(page: str) -> None:
    st.session_state.page = page
    st.session_state.selected_product_id = None
    st.query_params.clear()
    st.query_params["page"] = page


def _render_header() -> None:
    logo_col, spacer, delivery_col, cart_col = st.columns([1.5, 5.5, 1.2, 1.2])
    with logo_col:
        if st.button("FreshCart", key="logo-home", use_container_width=True):
            _set_page("home")
            st.rerun()
        st.image(str(get_logo_path()), width=110)
    with delivery_col:
        if st.button("Delivery", key="delivery-button", use_container_width=True):
            st.session_state.show_delivery = not st.session_state.show_delivery
    with cart_col:
        total_items = count_items(st.session_state.cart)
        if st.button(f"Cart ({total_items})", key="cart-button", use_container_width=True):
            _set_page("cart")
            st.rerun()

    if st.session_state.show_delivery:
        _render_delivery_status()


def _render_delivery_status() -> None:
    estimate = get_delivery_estimate()
    lines = build_cart_lines(st.session_state.cart, PRODUCTS)
    checkout_items = [
        f"{line.quantity} x {line.product.name} - {format_currency(line.subtotal)}"
        for line in lines
    ]
    if not checkout_items:
        checkout_items = st.session_state.last_checkout_items

    with st.container():
        st.header("Delivery status")
        # progress accepts 0-1 float; display status text nearby for clarity
        paid = st.session_state.payment_confirmation
        if not paid:
            st.warning("No items ready for delivery status yet.")
        else:
            try:
                st.progress(0.45, text=estimate.status)
            except TypeError:
                # older Streamlit versions may not support the text param
                st.progress(0.45)
                st.write(f"Status: {estimate.status}")
            st.info(
                f"{estimate.message} Estimated arrival: {estimate.display_time}. "
                f"Route: {estimate.origin} to {estimate.destination}. Delivery is within 24 hours."
            )
            if estimate.same_day:
                st.success("Same-day delivery is available for this address.")
            st.subheader("Checkout items")
            if checkout_items:
                for item in checkout_items:
                    st.write(item)
            else:
                st.caption("No checkout items yet.")


def _render_home_page() -> None:
    st.caption("Eat Fresh Daily.")
    st.title("Fresh groceries for same-day delivery")

    _render_product_grid()
    _render_recently_viewed_stack()

    if st.session_state.selected_product_id:
        _render_product_dialog(PRODUCTS[st.session_state.selected_product_id])


def _render_product_grid() -> None:
    product_items = list(PRODUCTS.values())
    for row_start in range(0, len(product_items), 3):
        cols = st.columns(3)
        for col, product in zip(cols, product_items[row_start : row_start + 3]):
            with col:
                _render_product_card(product)


def _render_product_card(product: Product) -> None:
    # Image + product meta displayed using Streamlit widgets (no HTML)
    st.image(str(product.image), use_container_width=True)
    st.caption(product.category)
    st.subheader(product.name)
    st.write(f"{product.unit} • {format_currency(product.price)}")
    if st.button(f"View {product.name}", key=f"view-{product.id}", use_container_width=True):
        _open_product(product.id)
        st.rerun()


def _open_product(product_id: str) -> None:
    _push_recent_product(product_id)
    st.session_state.selected_product_id = product_id
    st.session_state.detail_quantity = 1


def _push_recent_product(product_id: str) -> None:
    recent_stack: Stack[str] = Stack(
        item for item in st.session_state.recent_product_stack if item != product_id
    )
    recent_stack.push(product_id)
    st.session_state.recent_product_stack = recent_stack.to_list()[-5:]


def _render_recently_viewed_stack() -> None:
    recent_stack: Stack[str] = Stack(st.session_state.recent_product_stack)
    recent_products = [
        PRODUCTS[product_id]
        for product_id in reversed(recent_stack.to_list())
        if product_id in PRODUCTS
    ]

    if not recent_products:
        return

    st.markdown("### Recently viewed")
    cols = st.columns(min(3, len(recent_products)))
    for col, product in zip(cols, recent_products):
        with col:
            st.write("Top item" if product.id == recent_stack.peek() else "Other item")
            if st.button(product.name, key=f"recent-{product.id}", use_container_width=True):
                _open_product(product.id)
                st.rerun()


@st.dialog("Product details")
def _render_product_dialog(product: Product) -> None:
    st.image(str(product.image), use_container_width=True)
    detail_col, action_col = st.columns([2.2, 1])
    with detail_col:
        st.subheader(product.name)
        st.write(product.description)
        st.caption(f"{product.category} | {product.unit} | {product.stock} in stock")
        st.metric("Price", format_currency(product.price))
    with action_col:
        st.write("Quantity")
        qty_cols = st.columns([1, 1, 1])
        with qty_cols[0]:
            if st.button("-", key=f"detail-minus-{product.id}", use_container_width=True):
                st.session_state.detail_quantity = max(1, st.session_state.detail_quantity - 1)
        with qty_cols[1]:
            # show quantity using Streamlit markdown (no raw HTML)
            st.markdown(f"**{st.session_state.detail_quantity}**")
        with qty_cols[2]:
            if st.button("+", key=f"detail-plus-{product.id}", use_container_width=True):
                st.session_state.detail_quantity = min(product.stock, st.session_state.detail_quantity + 1)

        if st.button("Add to cart", key=f"add-{product.id}", type="primary", use_container_width=True):
            add_to_cart(st.session_state.cart, product.id, st.session_state.detail_quantity)
            st.toast(f"Added {st.session_state.detail_quantity} x {product.name} to cart.")
        if st.button("Close", key=f"close-{product.id}", use_container_width=True):
            st.session_state.selected_product_id = None
            st.query_params.clear()
            st.rerun()


def _render_cart_page() -> None:
    lines = build_cart_lines(st.session_state.cart, PRODUCTS)
    st.caption("Your basket")
    st.title("Shopping cart")

    if not lines:
        st.info("Your cart is empty. Add groceries from the homepage to start an order.")
        if st.button("Browse products", type="primary"):
            _set_page("home")
            st.rerun()
        return

    for line in lines:
        _render_cart_line(line.product, line.quantity)

    st.divider()
    total = cart_total(lines)
    total_col, checkout_col = st.columns([3, 1])
    with total_col:
        st.write("Cart total")
        st.subheader(format_currency(total))
        st.caption("Delivery fee is calculated on the payment page.")
    with checkout_col:
        if st.button("Checkout", type="primary", use_container_width=True):
            _set_page("payment")
            st.rerun()


def _render_cart_line(product: Product, quantity: int) -> None:
    line_cols = st.columns([1.1, 3, 1.2, 1.4])
    with line_cols[0]:
        st.image(str(product.image), use_container_width=True)
    with line_cols[1]:
        st.subheader(product.name)
        st.write(product.description)
        st.caption(f"{product.unit} | {format_currency(product.price)} each")
    with line_cols[2]:
        st.write("Quantity")
        st.subheader(str(quantity))
        qty_cols = st.columns(2)
        with qty_cols[0]:
            if st.button("-", key=f"cart-minus-{product.id}", use_container_width=True):
                decrease_quantity(st.session_state.cart, product.id)
                st.rerun()
        with qty_cols[1]:
            if st.button("+", key=f"cart-plus-{product.id}", use_container_width=True):
                add_to_cart(st.session_state.cart, product.id)
                st.rerun()
    with line_cols[3]:
        st.write("Subtotal")
        st.subheader(format_currency(product.price * quantity))
        if st.button("Remove", key=f"remove-{product.id}", use_container_width=True):
            remove_from_cart(st.session_state.cart, product.id)
            st.rerun()


def _render_payment_page() -> None:
    lines = build_cart_lines(st.session_state.cart, PRODUCTS)
    summary = create_payment_summary(lines)
    st.caption("Secure checkout")
    st.title("Payment")

    if not lines:
        if st.session_state.payment_confirmation:
            _render_confirmation()
            if st.button("Check delivery status", type="primary"):
                st.session_state.show_delivery = True
                _set_page("home")
                st.rerun()
            return
        st.warning("Your cart is empty. Please add products before checkout.")
        if st.button("Back to home", type="primary"):
            _set_page("home")
            st.rerun()
        return

    st.subheader("Order summary")
    for line in summary.lines:
        st.write(
            f"{line.quantity} x {line.product.name} - "
            f"{line.product.description} - {format_currency(line.subtotal)}"
        )

    totals_col, method_col = st.columns([1.2, 1])
    with totals_col:
        st.metric("Subtotal", format_currency(summary.subtotal))
        st.metric("Delivery fee", format_currency(summary.delivery_fee))
        st.metric("Total amount to pay", format_currency(summary.total))
    with method_col:
        st.subheader("Payment method")
        for method in PAYMENT_METHODS:
            selected = st.session_state.payment_method == method
            button_type = "primary" if selected else "secondary"
            if st.button(method, key=f"method-{method}", type=button_type, use_container_width=True):
                st.session_state.payment_method = method
                st.session_state.payment_confirmation = None
                st.rerun()

    _, pay_col = st.columns([3, 1])
    with pay_col:
        if st.button("Pay", key="pay-button", type="primary", use_container_width=True):
            try:
                st.session_state.payment_confirmation = confirm_payment(
                    st.session_state.payment_method,
                    summary.total,
                )
                st.session_state.last_checkout_items = [
                    f"{line.quantity} x {line.product.name} - {format_currency(line.subtotal)}"
                    for line in summary.lines
                ]
                st.session_state.fulfillment_queue = create_fulfillment_queue(summary.lines).to_list()
                st.session_state.cart = {}
            except ValueError as exc:
                st.error(str(exc))

    if st.session_state.payment_confirmation:
        _render_confirmation()


def _render_confirmation() -> None:
    confirmation = st.session_state.payment_confirmation
    st.success(confirmation.message)
    st.info(
        f"Order {confirmation.order_id} paid with {confirmation.payment_method}. "
        "Check the delivery status in the homepage."
    )
