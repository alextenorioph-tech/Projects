from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo


IMAGE_DIR = Path(__file__).resolve().parent.parent / "images"
STORE_NAME = "FreshCart"
STORE_ADDRESS = "Zabarte, Quezon City"
DELIVERY_ADDRESS = "NU Fairview, Quezon City"
CURRENCY = "PHP"


@dataclass(frozen=True)
class Product:
    """Immutable catalog item so displayed prices and descriptions stay consistent."""

    id: str
    name: str
    description: str
    price: float
    image: Path
    category: str
    unit: str
    stock: int


@dataclass(frozen=True)
class DeliveryEstimate:
    """Delivery information is separated from the UI so it can be tested or reused."""

    origin: str
    destination: str
    status: str
    message: str
    estimated_arrival: datetime
    same_day: bool

    @property
    def display_time(self) -> str:
        return self.estimated_arrival.strftime("%I:%M %p")


def get_products() -> dict[str, Product]:
    """Return the grocery catalog used by the storefront."""

    return {
        "wagyu-steak": Product(
            id="wagyu-steak",
            name="Wagyu Steak",
            description=(
                "Premium marbled beef steak prepared for special meals, packed chilled "
                "and ready for pan-searing or grilling."
            ),
            price=1999.99,
            image=IMAGE_DIR / "Wagyu.png",
            category="Meat",
            unit="500 g pack",
            stock=8,
        ),
        "tenderloin-steak": Product(
            id="tenderloin-steak",
            name="Tenderloin Steak",
            description=(
                "Lean and tender beef cut with a clean flavor, ideal for quick dinners, "
                "steak plates, and protein-focused meals."
            ),
            price=399.99,
            image=IMAGE_DIR / "Tenderloin.png",
            category="Meat",
            unit="350 g pack",
            stock=16,
        ),
        "cabbage": Product(
            id="cabbage",
            name="Cabbage",
            description=(
                "Fresh green cabbage with crisp leaves for salads, stir-fries, soups, "
                "and everyday home cooking."
            ),
            price=30.00,
            image=IMAGE_DIR / "Cabbage.png",
            category="Produce",
            unit="1 head",
            stock=40,
        ),
        "potatoes": Product(
            id="potatoes",
            name="Potatoes",
            description=(
                "Versatile table potatoes for roasting, mashing, frying, and hearty "
                "grocery staples."
            ),
            price=50.00,
            image=IMAGE_DIR / "Potatoes.png",
            category="Produce",
            unit="1 kg bag",
            stock=32,
        ),
        "milk": Product(
            id="milk",
            name="Milk",
            description=(
                "Creamy dairy milk for breakfast, baking, coffee, and family grocery "
                "essentials."
            ),
            price=169.99,
            image=IMAGE_DIR / "Milk.png",
            category="Dairy",
            unit="1 L carton",
            stock=24,
        ),
        "cheese": Product(
            id="cheese",
            name="Cheese",
            description=(
                "Rich sliced cheese for sandwiches, snack plates, burgers, and quick "
                "meal prep."
            ),
            price=150.00,
            image=IMAGE_DIR / "cheese.png",
            category="Dairy",
            unit="200 g pack",
            stock=20,
        ),
    }


def get_logo_path() -> Path:
    return IMAGE_DIR / "FreshCart.png"


def format_currency(amount: float) -> str:
    return f"{CURRENCY} {amount:,.2f}"


def get_delivery_estimate(now: datetime | None = None) -> DeliveryEstimate:
    """Estimate delivery from Zabarte to NU Fairview and keep the promise under 24 hours."""

    local_now = now or datetime.now(ZoneInfo("Asia/Manila"))
    estimated_arrival = local_now + timedelta(hours=2, minutes=15)

    return DeliveryEstimate(
        origin=STORE_ADDRESS,
        destination=DELIVERY_ADDRESS,
        status="Same-day delivery",
        message="Preparing orders for dispatch from Zabarte to NU Fairview.",
        estimated_arrival=estimated_arrival,
        same_day=estimated_arrival.date() == local_now.date(),
    )
