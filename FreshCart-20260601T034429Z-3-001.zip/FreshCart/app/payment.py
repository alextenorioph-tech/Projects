from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import uuid4

from cart import CartLine, cart_total
from data_structures import Queue


PAYMENT_METHODS = ("Credit Card", "E-wallet", "Cash on Delivery")


@dataclass(frozen=True)
class PaymentSummary:
    """Checkout totals are calculated outside Streamlit to keep the UI thin."""

    lines: list[CartLine]
    subtotal: float
    delivery_fee: float
    total: float


@dataclass(frozen=True)
class PaymentConfirmation:
    order_id: str
    message: str
    paid_at: datetime
    payment_method: str


def create_payment_summary(lines: list[CartLine]) -> PaymentSummary:
    subtotal = cart_total(lines)
    delivery_fee = 0.0 if subtotal >= 1000 or subtotal == 0 else 49.00
    return PaymentSummary(
        lines=lines,
        subtotal=subtotal,
        delivery_fee=delivery_fee,
        total=subtotal + delivery_fee,
    )


def create_fulfillment_queue(lines: list[CartLine]) -> Queue[str]:
    """Build the checkout work queue in the order staff should process it."""

    queue: Queue[str] = Queue()
    queue.enqueue("Verify payment and order details")
    for line in lines:
        queue.enqueue(f"Pack {line.quantity} x {line.product.name}")
    queue.enqueue("Hand order to rider for same-day delivery")
    return queue


def confirm_payment(payment_method: str, total: float) -> PaymentConfirmation:
    """Create a confirmation record for the UI after a valid payment action."""

    if payment_method not in PAYMENT_METHODS:
        raise ValueError("Please select a payment method before paying.")
    if total <= 0:
        raise ValueError("Your cart is empty.")

    return PaymentConfirmation(
        order_id=f"FC-{uuid4().hex[:8].upper()}",
        message=(
            "Payment confirmed. Thank you for your purchase! Please check the "
            "delivery status in the homepage."
        ),
        paid_at=datetime.now(),
        payment_method=payment_method,
    )
